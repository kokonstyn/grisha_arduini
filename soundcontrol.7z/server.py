from http.server import BaseHTTPRequestHandler,HTTPServer
import sound 
#import com

class HttpProcessor(BaseHTTPRequestHandler):
    def do_GET(self):
        print(self.path[1:])
        soundlevel = int(self.path[1:])/100
        print(soundlevel)

        ev = sound.IAudioEndpointVolume.get_default()
        vol = ev.GetMasterVolumeLevelScalar()
        if soundlevel>0.2:
            ev.SetMute(0)

        ev.SetMasterVolumeLevelScalar(soundlevel)
        self.send_response(200)
        self.send_header('content-type','text/html')
        self.end_headers()
        self.wfile.write(str(self.path[1:]).encode())
        

#print(vol)

serv = HTTPServer(("",80),HttpProcessor)
serv.serve_forever()
